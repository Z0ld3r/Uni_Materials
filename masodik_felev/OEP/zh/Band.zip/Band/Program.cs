﻿using System;
using System.Collections.Generic;
using TextFile;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.InteropServices;
using System.Transactions;

namespace Band
{
    class Program
    {
        static void Main()
        {
            // Osztályok
            // Közepes szinthez
            //bool validLayout = TestClassSatisfactory();
            //Console.WriteLine("\nSatisfactory Class Layout is " + (validLayout ? "correct" : "incorrect"));

            // Jeles szinthez
            // validLayout = TestClassExcellent();
            // Console.WriteLine("\nExcellent Class Layout is " + (validLayout ? "correct" : "incorrect"));

            // Olvasás
            // Console.WriteLine();
            Read("band.txt");
        }

        static void Read(String filename)
        {
            TextFileReader reader = new(filename);
            List<Band> bands = new List<Band>();

            reader.ReadString(out string bandName);
            reader.ReadInt(out int numOfAlbums);
            reader.ReadInt(out int numOfConcerts);

            Band band = new Band(new List<Album>(), new List<Concert>());

            List<Album> albums = new List<Album>();
            for (int j = 0; j < numOfAlbums; j++)
            {
                reader.ReadString(out string albumName);
                reader.ReadInt(out int releaseYear);
                reader.ReadInt(out int albumLength);

                List<Song> curAlbumSongs = new List<Song>();
                for (int k = 0; k < albumLength; k++)
                {
                    reader.ReadString(out string songName);
                    reader.ReadInt(out int songLength);
                    Song curSong = new Song(songName, songLength);
                    curAlbumSongs.Add(curSong);
                }

                Album curAlbum = new Album(albumName, releaseYear, curAlbumSongs);
                band.Publish(albumName, releaseYear, curAlbumSongs);
                albums.Add(curAlbum);
            }

            List<Concert> concerts = new List<Concert>();

            for (int i = 0; i < numOfConcerts; i++)
            {
                reader.ReadString(out string concertName);
                reader.ReadString(out string concertLocation);
                reader.ReadInt(out int concertLength);

                List<Song> curConcertSongs = new List<Song>();
                for (int j = 0; j < concertLength; j++)
                {
                    reader.ReadString(out string songName);

                    Song? curSong = band.GetSongByTitle(songName);
                    if (curSong != null)
                    {
                        curConcertSongs.Add(curSong);
                    }
                }
                band.Play(concertLocation, curConcertSongs);
            }

            // Közepes szinthez
            Console.WriteLine(band.LongestOnShortest());

            // Jeles szinthez
            reader.ReadInt(out int numOfMembers);
            for (int j = 0; j < numOfMembers; j++)
            {
                reader.ReadString(out string type);
                reader.ReadString(out string name);
                reader.ReadInt(out int age);
                reader.ReadString(out string songName);

                Song? curSong = band.GetSongByTitle(songName);
                if (curSong != null)
                {
                    switch (type)
                    {
                        case "Singer":
                            band.NewMember(new Singer(name, age, curSong));
                            break;
                        case "Drummer":
                            band.NewMember(new Drummer(name, age, curSong));
                            break;
                        case "Guitarist":
                            band.NewMember(new Guitarist(name, age, curSong));
                            break;
                        default:
                            throw new Exception("Invalid musician type: " + type);
                    }
                }
            }

            Console.WriteLine(band.AgeSum());
            Console.WriteLine(band.OldestFavourite());
        }

        static bool TestClassSatisfactory()
        {
            Console.WriteLine("Class Layout: ");

            bool validLayout = true;

            // Song
            Console.WriteLine("Song: ");

            Type song = typeof(Song);
            FieldInfo[] fieldInfo = song.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);

            bool songFieldsCorrect = fieldInfo.Count(f => f.FieldType == typeof(string)) == 1;
            songFieldsCorrect &= fieldInfo.Count(f => f.FieldType == typeof(int)) == 1;

            validLayout &= songFieldsCorrect;
            Console.WriteLine($" - Song fields are correct: {songFieldsCorrect}");

            bool songConstructorCorrect = song.GetConstructor(new Type[] { typeof(string), typeof(int) }) != null;

            validLayout &= songConstructorCorrect;
            Console.WriteLine($" - Song constructor is correct: {songConstructorCorrect}");

            // Album
            Console.WriteLine("\nAlbum: ");

            Type album = typeof(Album);
            fieldInfo = album.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);

            bool albumFieldsCorrect = fieldInfo.Count(f => f.FieldType == typeof(string)) == 1;
            albumFieldsCorrect &= fieldInfo.Count(f => f.FieldType == typeof(int)) == 1;
            albumFieldsCorrect &= (fieldInfo.Count(f => f.FieldType == typeof(List<Song>)) == 1 || fieldInfo.Count(f => f.FieldType == typeof(Song[])) == 1);

            validLayout &= albumFieldsCorrect;
            Console.WriteLine($" - Album fields are correct: {albumFieldsCorrect}");

            bool albumConstructorCorrect = (album.GetConstructor(new Type[] { typeof(string), typeof(int), typeof(List<Song>) }) != null || album.GetConstructor(new Type[] { typeof(string), typeof(int), typeof(Song[]) }) != null);

            validLayout &= albumConstructorCorrect;
            Console.WriteLine($" - Album constructor is correct: {albumConstructorCorrect}");

            MethodInfo method = album.GetMethod("LongestSong")!;
            bool albumMethodsCorrect = method != null;
            albumMethodsCorrect &= method?.GetParameters().Length == 0;
            albumMethodsCorrect &= method?.ReturnType == typeof(Song);

            validLayout &= albumMethodsCorrect;
            Console.WriteLine($" - Album methods are correct: {albumMethodsCorrect}");

            // Concert
            Console.WriteLine("\nConcert: ");

            Type concert = typeof(Concert);
            fieldInfo = concert.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);

            bool concertFieldsCorrect = fieldInfo.Count(f => f.FieldType == typeof(string)) == 1;
            concertFieldsCorrect &= fieldInfo.Count(f => f.FieldType == typeof(Band)) == 1;
            concertFieldsCorrect &= (fieldInfo.Count(f => f.FieldType == typeof(List<Song>)) == 1 || fieldInfo.Count(f => f.FieldType == typeof(Song[])) == 1);

            validLayout &= concertFieldsCorrect;
            Console.WriteLine($" - Concert fields are correct: {concertFieldsCorrect}");

            bool concertConstructorCorrect = (concert.GetConstructor(new Type[] { typeof(string), typeof(List<Song>), typeof(Band) }) != null || concert.GetConstructor(new Type[] { typeof(string), typeof(Song[]), typeof(Band) }) != null);

            validLayout &= concertConstructorCorrect;
            Console.WriteLine($" - Concert constructor is correct: {concertConstructorCorrect}");

            method = concert.GetMethod("Length")!;
            bool concertMethodsCorrect = method != null;
            albumMethodsCorrect &= method?.GetParameters().Length == 0;
            albumMethodsCorrect &= method?.ReturnType == typeof(int);

            validLayout &= concertMethodsCorrect;
            Console.WriteLine($" - Concert methods are correct: {concertMethodsCorrect}");

            // Band
            Console.WriteLine("\nBand: ");

            Type band = typeof(Band);
            fieldInfo = band.GetFields();

            bool bandFieldsCorrect = (fieldInfo.Count(f => f.FieldType == typeof(List<Album>)) == 1 || fieldInfo.Count(f => f.FieldType == typeof(Album[])) == 1);
            bandFieldsCorrect &= (fieldInfo.Count(f => f.FieldType == typeof(List<Concert>)) == 1 || fieldInfo.Count(f => f.FieldType == typeof(Concert[])) == 1);

            validLayout &= bandFieldsCorrect;
            Console.WriteLine($" - Band fields are correct: {bandFieldsCorrect}");

            bool bandConstructorCorrect = (band.GetConstructor(new Type[] { typeof(List<Album>), typeof(List<Concert>) }) != null || band.GetConstructor(new Type[] { typeof(Album[]), typeof(Concert[]) }) != null);

            validLayout &= bandConstructorCorrect;
            Console.WriteLine($" - Band constructor is correct: {bandConstructorCorrect}");

            method = band.GetMethod("IsValidSong")!;
            bool bandMethodsCorrect = method != null;
            bandMethodsCorrect &= method?.GetParameters().Count(p => p.ParameterType == typeof(Song)) == 1;
            bandMethodsCorrect &= method?.ReturnType == typeof(bool);

            method = band.GetMethod("Publish")!;
            bandMethodsCorrect &= method != null;
            bandMethodsCorrect &= method?.GetParameters().Count(p => p.ParameterType == typeof(string)) == 1;
            bandMethodsCorrect &= method?.GetParameters().Count(p => p.ParameterType == typeof(int)) == 1;
            bandMethodsCorrect &= (method?.GetParameters().Count(p => p.ParameterType == typeof(Song[])) == 1 || method?.GetParameters().Count(p => p.ParameterType == typeof(List<Song>)) == 1);
            bandMethodsCorrect &= method?.ReturnType == typeof(void);

            method = band.GetMethod("Play")!;
            bandMethodsCorrect &= method != null;
            bandMethodsCorrect &= method?.GetParameters().Count(p => p.ParameterType == typeof(string)) == 1;
            bandMethodsCorrect &= (method?.GetParameters().Count(p => p.ParameterType == typeof(Song[])) == 1 || method?.GetParameters().Count(p => p.ParameterType == typeof(List<Song>)) == 1);
            bandMethodsCorrect &= method?.ReturnType == typeof(void);

            method = band.GetMethod("LongestSong")!;
            bandMethodsCorrect &= method != null;
            bandMethodsCorrect &= method?.GetParameters().Length == 0;
            bandMethodsCorrect &= method?.ReturnType == typeof(Song);

            method = band.GetMethod("ShortestConcert")!;
            bandMethodsCorrect &= method != null;
            bandMethodsCorrect &= method?.GetParameters().Length == 0;
            bandMethodsCorrect &= method?.ReturnType == typeof(Concert);

            method = band.GetMethod("LongestOnShortest")!;
            bandMethodsCorrect &= method != null;
            bandMethodsCorrect &= method?.GetParameters().Length == 0;
            bandMethodsCorrect &= method?.ReturnType == typeof(bool);

            method = band.GetMethod("GetSongByTitle")!;
            bandMethodsCorrect &= method != null;
            bandMethodsCorrect &= method?.GetParameters().Count(p => p.ParameterType == typeof(string)) == 1;
            bandMethodsCorrect &= method?.ReturnType == typeof(Song);

            validLayout &= bandMethodsCorrect;
            Console.WriteLine($" - Band methods are correct: {bandMethodsCorrect}");

            return validLayout;
        }

        static bool TestClassExcellent()
        {
            bool validLayout = true;

            // Song
            Console.WriteLine("\nMusician: ");

            Type musician = typeof(Musician);
            FieldInfo[] fieldInfo = musician.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);

            bool musicianIsAbstract = musician.IsAbstract;
            Console.WriteLine($" - Musician is abstract: {musicianIsAbstract}");

            bool musicianFieldsCorrect = fieldInfo.Count(f => f.FieldType == typeof(string)) == 1;
            musicianFieldsCorrect &= fieldInfo.Count(f => f.FieldType == typeof(int)) == 1;
            musicianFieldsCorrect &= fieldInfo.Count(f => f.FieldType == typeof(Song)) == 1;

            validLayout &= musicianFieldsCorrect;
            Console.WriteLine($" - Musician fields are correct: {musicianFieldsCorrect}");

            bool musicianConstructorCorrect = musician.GetConstructor(BindingFlags.NonPublic | BindingFlags.Instance, new Type[] { typeof(string), typeof(int), typeof(Song) }) != null;

            validLayout &= musicianConstructorCorrect;
            Console.WriteLine($" - Musician constructor is correct: {musicianConstructorCorrect}");

            MethodInfo method = musician.GetMethod("IsSinger")!;
            bool musicianMethodsCorrect = method != null;
            musicianMethodsCorrect &= method?.GetParameters().Length == 0;
            musicianMethodsCorrect &= method?.ReturnType == typeof(bool);
            musicianMethodsCorrect &= method?.IsVirtual ?? false;

            method = musician.GetMethod("IsGuitarist")!;
            musicianMethodsCorrect = method != null;
            musicianMethodsCorrect &= method?.GetParameters().Length == 0;
            musicianMethodsCorrect &= method?.ReturnType == typeof(bool);
            musicianMethodsCorrect &= method?.IsVirtual ?? false;

            method = musician.GetMethod("IsDrummer")!;
            musicianMethodsCorrect = method != null;
            musicianMethodsCorrect &= method?.GetParameters().Length == 0;
            musicianMethodsCorrect &= method?.ReturnType == typeof(bool);
            musicianMethodsCorrect &= method?.IsVirtual ?? false;

            validLayout &= musicianMethodsCorrect;
            Console.WriteLine($" - Musician methods are correct: {musicianMethodsCorrect}");

            // Singer
            Console.WriteLine("\nSinger: ");

            Type singer = typeof(Singer);
            fieldInfo = singer.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);

            Singer singerInstance = new Singer("", 0, new Song("", 0));

            bool singerIsDerivedFromMusician = singer.BaseType == typeof(Musician);
            validLayout &= singerIsDerivedFromMusician;
            Console.WriteLine($" - Singer is derived from Musician : {singerIsDerivedFromMusician}");

            bool singerFieldsCorrect = fieldInfo.Count(f => f.FieldType == typeof(string)) == 1;
            singerFieldsCorrect &= fieldInfo.Count(f => f.FieldType == typeof(int)) == 1;
            singerFieldsCorrect &= fieldInfo.Count(f => f.FieldType == typeof(Song)) == 1;

            validLayout &= singerFieldsCorrect;
            Console.WriteLine($" - Singer fields are correct: {singerFieldsCorrect}");

            bool singerConstructorCorrect = singer.GetConstructor(new Type[] { typeof(string), typeof(int), typeof(Song) }) != null;

            validLayout &= singerConstructorCorrect;
            Console.WriteLine($" - Singer constructor is correct: {singerConstructorCorrect}");

            method = singer.GetMethod("IsSinger")!;
            bool singerMethodsCorrect = method.DeclaringType == typeof(Singer);
            singerMethodsCorrect &= method?.GetParameters().Length == 0;
            singerMethodsCorrect &= method?.ReturnType == typeof(bool);
            singerMethodsCorrect &= singerInstance.IsSinger() == true;

            method = singer.GetMethod("IsDrummer")!;
            singerMethodsCorrect = method.DeclaringType == typeof(Musician);
            singerMethodsCorrect &= singerInstance.IsDrummer() == false;

            method = singer.GetMethod("IsGuitarist")!;
            singerMethodsCorrect = method.DeclaringType == typeof(Musician);
            singerMethodsCorrect &= singerInstance.IsGuitarist() == false;

            validLayout &= singerMethodsCorrect;
            Console.WriteLine($" - Singer methods are correct: {singerMethodsCorrect}");

            // Drummer
            Console.WriteLine("\nDrummer: ");

            Type drummer = typeof(Drummer);
            fieldInfo = drummer.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);

            Drummer drummerInstance = new Drummer("", 0, new Song("", 0));

            bool drummerIsDerivedFromMusician = drummer.BaseType == typeof(Musician);
            validLayout &= drummerIsDerivedFromMusician;
            Console.WriteLine($" - Drummer is derived from Musician : {drummerIsDerivedFromMusician}");

            bool drummerFieldsCorrect = fieldInfo.Count(f => f.FieldType == typeof(string)) == 1;
            drummerFieldsCorrect &= fieldInfo.Count(f => f.FieldType == typeof(int)) == 1;
            drummerFieldsCorrect &= fieldInfo.Count(f => f.FieldType == typeof(Song)) == 1;

            validLayout &= drummerFieldsCorrect;
            Console.WriteLine($" - Drummer fields are correct: {drummerFieldsCorrect}");

            bool drummerConstructorCorrect = drummer.GetConstructor(new Type[] { typeof(string), typeof(int), typeof(Song) }) != null;

            validLayout &= drummerConstructorCorrect;
            Console.WriteLine($" - Drummer constructor is correct: {drummerConstructorCorrect}");

            method = drummer.GetMethod("IsSinger")!;
            bool drummerMethodsCorrect = method.DeclaringType == typeof(Musician);
            drummerMethodsCorrect &= drummerInstance.IsSinger() == false;

            method = drummer.GetMethod("IsDrummer")!;
            drummerMethodsCorrect = method.DeclaringType == typeof(Drummer);
            drummerMethodsCorrect &= method?.GetParameters().Length == 0;
            drummerMethodsCorrect &= method?.ReturnType == typeof(bool);
            drummerMethodsCorrect &= drummerInstance.IsDrummer() == true;

            method = drummer.GetMethod("IsGuitarist")!;
            drummerMethodsCorrect = method.DeclaringType == typeof(Musician);
            drummerMethodsCorrect &= drummerInstance.IsGuitarist() == false;

            validLayout &= drummerMethodsCorrect;
            Console.WriteLine($" - Drummer methods are correct: {drummerMethodsCorrect}");

            // Guitarist
            Console.WriteLine("\nGuitarist: ");

            Type guitarist = typeof(Guitarist);
            fieldInfo = guitarist.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);

            Guitarist guitaristInstance = new Guitarist("", 0, new Song("", 0));

            bool guitaristIsDerivedFromMusician = guitarist.BaseType == typeof(Musician);
            validLayout &= guitaristIsDerivedFromMusician;
            Console.WriteLine($" - Guitarist is derived from Musician : {guitaristIsDerivedFromMusician}");

            bool guitaristFieldsCorrect = fieldInfo.Count(f => f.FieldType == typeof(string)) == 1;
            guitaristFieldsCorrect &= fieldInfo.Count(f => f.FieldType == typeof(int)) == 1;
            guitaristFieldsCorrect &= fieldInfo.Count(f => f.FieldType == typeof(Song)) == 1;

            validLayout &= guitaristFieldsCorrect;
            Console.WriteLine($" - Guitarist fields are correct: {guitaristFieldsCorrect}");

            bool guitaristConstructorCorrect = guitarist.GetConstructor(new Type[] { typeof(string), typeof(int), typeof(Song) }) != null;

            validLayout &= guitaristConstructorCorrect;
            Console.WriteLine($" - Guitarist constructor is correct: {guitaristConstructorCorrect}");

            method = guitarist.GetMethod("IsSinger")!;
            bool guitaristMethodsCorrect = method.DeclaringType == typeof(Musician);
            guitaristMethodsCorrect &= guitaristInstance.IsSinger() == false;

            method = guitarist.GetMethod("IsDrummer")!;
            guitaristMethodsCorrect = method.DeclaringType == typeof(Musician);
            guitaristMethodsCorrect &= guitaristInstance.IsDrummer() == false;

            method = guitarist.GetMethod("IsGuitarist")!;
            guitaristMethodsCorrect = method.DeclaringType == typeof(Guitarist);
            guitaristMethodsCorrect &= method?.GetParameters().Length == 0;
            guitaristMethodsCorrect &= method?.ReturnType == typeof(bool);
            guitaristMethodsCorrect &= guitaristInstance.IsGuitarist() == true;

            validLayout &= guitaristMethodsCorrect;
            Console.WriteLine($" - Guitarist methods are correct: {guitaristMethodsCorrect}");

            // Band
            Console.WriteLine("\nBand: ");

            Type band = typeof(Band);
            fieldInfo = band.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);

            bool bandFieldsCorrect = (fieldInfo.Count(f => f.FieldType == typeof(List<Musician>)) == 1 || fieldInfo.Count(f => f.FieldType == typeof(Musician[])) == 1);

            validLayout &= bandFieldsCorrect;
            Console.WriteLine($" - New Band fields are correct: {bandFieldsCorrect}");

            method = band.GetMethod("AgeSum")!;
            bool bandMethodsCorrect = method != null;
            bandMethodsCorrect &= method?.GetParameters().Length == 0;
            bandMethodsCorrect &= method?.ReturnType == typeof(int);

            method = band.GetMethod("OldestFavourite")!;
            bandMethodsCorrect &= method != null;
            bandMethodsCorrect &= method?.GetParameters().Length == 0;
            bandMethodsCorrect &= method?.ReturnType == typeof(string);

            method = band.GetMethod("NewMember")!;
            bandMethodsCorrect &= method != null;
            bandMethodsCorrect &= method?.GetParameters().Count(p => p.ParameterType == typeof(Musician)) == 1;
            bandMethodsCorrect &= method?.ReturnType == typeof(void);

            validLayout &= bandMethodsCorrect;
            Console.WriteLine($" - New Band methods are correct: {bandMethodsCorrect}");

            return validLayout;
        }
    }
}