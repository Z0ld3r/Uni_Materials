﻿//Author: Leszkovszky Alexandra
//Date: 2022.03.28

namespace Patterns
{
    public class TemplateMethod
    {
        //Sablonfüggvény:
        //A sablonfüggvény minta egy algoritmus alapvázát határozza meg egy absztrakt osztályban, miközben a konkrét lépéseket az alosztályokra bízza.
        //Ezért a konkrét lépések el is térhetnek egymástól az alosztályok között.

        //Példa:
        //A Beverage(ital) osztály egy Prepare() metódust tartalmaz, amely az ital készítésének folyamatát határozza meg.
        //A Brew() és AddCondiments() metódusokat a konkrét italosztályok (pl.Tea és Coffee) implementálják.

        //Miért használnánk ezt a mintát:
        //Ha egy algoritmus fő szerkezetét rögzíteni akarjuk, de a konkrét lépéseket változtathatóvá szeretnénk tenni.
        //Ez elősegíti a kód újrafelhasználhatóságát és az egyértelmű szerkezetet.
        //Kényelmes az olyan problémákhoz, ahol több osztály ugyanazt a műveletet végzi, de kis eltérésekkel.
        abstract class Beverage
        {
            public void Prepare() // Maga a sablonfüggvény, mely belső lépésekből áll
            {
                BoilWater();
                Brew();
                PourInCup();
                AddCondiments();
            }
            private void BoilWater()
            {
                Console.WriteLine("Boiling water...");
            }
            protected abstract void Brew();

            private void PourInCup()
            {
                Console.WriteLine("Pouring into cup...");
            }

            protected abstract void AddCondiments();
        }

        class Tea : Beverage
        {
            protected override void Brew()
            {
                Console.WriteLine("Steeping the tea...");
            }

            protected override void AddCondiments()
            {
                Console.WriteLine("Adding lemon...");
            }
        }

        class Coffee : Beverage
        {
            protected override void Brew()
            {
                Console.WriteLine("Dripping coffee through filter...");
            }

            protected override void AddCondiments()
            {
                Console.WriteLine("Adding sugar and milk...");
            }
        } // Itt észrevehető, hogy külön-külön implementálják a lépéseket és ezek különböznek.

        class Program
        {
            static void Main()
            {
                Beverage tea = new Tea();
                tea.Prepare();

                Console.WriteLine();

                Beverage coffee = new Coffee();
                coffee.Prepare();
            }
        }
    }
}
