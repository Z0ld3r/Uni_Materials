﻿//Author: Leszkovszky Alexandra
//Date: 2022.03.28

namespace Patterns
{
    //Összetétel:
    //Az összetétel minta lehetővé teszi, hogy egyéni objektumokat és összetett objektumokat ugyanúgy kezeljünk egy hierarchikus struktúrában. (általában fastruktúra)

    //Példa:
    //Az IComponent interfész definiálja a ShowDetails() metódust. A Leaf osztály egy egyszerű objektumot képvisel, míg a Composite osztály
    //más objektumokat(leveleket vagy további összetett objektumokat) tartalmazhat. A Main() metódusban létrehozunk egy hierarchikus struktúrát,
    //amely tartalmaz különálló leveleket és egy másik összetett objektumot(SubTree).

    //Miért használnánk ezt a mintát:
    //Ha fában szervezett struktúrát kell kezelni(pl.fájlrendszerek, menük, UI elemek). Lehetővé teszi az egyedi
    //és összetett objektumok egységes kezelését, emellett rugalmasabb és átláthatóbb szerkezetet biztosít az adatok tárolására és kezelésére.
    interface IComponent
    {
        void ShowDetails();
    }
    class Leaf : IComponent
    {
        private string name;

        public Leaf(string name)
        {
            this.name = name;
        }

        public void ShowDetails()
        {
            Console.WriteLine($"Leaf: {name}");
        }
    }
    class Composite : IComponent
    {
        private string name;
        private List<IComponent> children = new List<IComponent>();

        public Composite(string name)
        {
            this.name = name;
        }

        public void Add(IComponent component)
        {
            children.Add(component);
        }

        public void ShowDetails()
        {
            Console.WriteLine($"Composite: {name}");
            foreach (var child in children)
            {
                child.ShowDetails();
            }
        }
    }
    class Program
    {
        static void Main()
        {
            Composite root = new Composite("Root");
            root.Add(new Leaf("Leaf 1"));
            root.Add(new Leaf("Leaf 2"));

            Composite subTree = new Composite("SubTree");
            subTree.Add(new Leaf("Leaf 3"));
            root.Add(subTree);

            root.ShowDetails();
        }
    }
}
