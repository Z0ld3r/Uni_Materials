﻿//Author: Leszkovszky Alexandra
//Date: 2022.03.28

namespace Patterns
{
    public class Prototype
    {
        //Prototípus:
        //A prototípus minta lehetővé teszi objektumok másolását anélkül, hogy új példányokat hoznánk létre az osztály konstruktoraival.

        //Példa:
        //A Person osztály implementálja az IPrototype interfészt, amely tartalmaz egy Clone() metódust.
        //Ez a metódus egy új Person példányt hoz létre az eredeti objektum alapján.
        //A Main() metódusban létrehozunk egy original példányt, majd lemásoljuk, és mindkettőt kiírjuk a konzolra.

        //Miért használnánk ezt a mintát:
        //Ha egy objektum létrehozása erőforrás-igényes, egy már létező objektum másolása gyorsabb lehet. Illetve
        //rugalmasságot biztosít az objektumok másolásánál (pl. mély és sekély másolatok kezelése).
        interface IPrototype
        {
            IPrototype Clone();
        }
        class Person : IPrototype
        {
            public string Name { get; set; }

            public Person(string name)
            {
                Name = name;
            }

            public IPrototype Clone()
            {
                return new Person(this.Name); // Mély másolat (más másolás is megengedett)
            }

            public override string ToString()
            {
                return $"Person: {Name}";
            }
        }
        public class Program
        {
            static void Main()
            {
                Person original = new Person("John");
                Person clone = (Person)original.Clone();

                Console.WriteLine(original);
                Console.WriteLine(clone);
            }
        }
    }
}
