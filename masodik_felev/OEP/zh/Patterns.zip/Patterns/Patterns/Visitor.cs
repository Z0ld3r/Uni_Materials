﻿//Author: Leszkovszky Alexandra
//Date: 2022.03.28

namespace Patterns
{
    public class Visitor
    {
        //Látogató:
        //Itt egy látogató objektumot használunk, amely megváltoztatja egy elem objektum végrehajtási algoritmusát.
        //Így amikor a látogató változik, az elem objektum végrehajtási algoritmusa is változhat. Az elem objektumnak fogadnia kell a látogató objektumot,
        //hogy a látogató objektum kezelje az elem objektumon végrehajtott műveletet.

        //Példa:
        //Van egy dokumentumfa hierarchia, ahol különböző típusú dokumentumok(pl.text dokumentum, image stb.) vannak,
        //és hozzáadhatunk új műveleteket az egyes dokumentum típusokhoz anélkül, hogy módosítanánk magukat a dokumentum osztályokat.

        //Miért használnánk ezt a mintát:
        //Ez általában olyan helyzetekben hasznos, ahol egy objektum hierarchiájához új műveleteket kell hozzáadni anélkül, hogy módosítanánk az objektumokat.
        interface IDocumentElement
        {
            void Accept(IVisitor visitor);
        }

        // Konkrét dokumentum elem: Szöveges dokumentum
        class TextDocument : IDocumentElement
        {
            public void Accept(IVisitor visitor)
            {
                visitor.VisitTextDocument(this);
            }
        }

        // Konkrét dokumentum elem: Kép
        class Image : IDocumentElement
        {
            public void Accept(IVisitor visitor)
            {
                visitor.VisitImage(this);
            }
        }

        // Látogató interfész, ami lehetővé teszi új műveletek hozzáadását a dokumentumokhoz
        interface IVisitor
        {
            void VisitTextDocument(TextDocument document);
            void VisitImage(Image image);
        }

        // Konkrét látogató, ami kiírja az egyes dokumentum típusok nevét
        class DocumentPrinter : IVisitor
        {
            public void VisitTextDocument(TextDocument document)
            {
                Console.WriteLine("Text Document");
            }

            public void VisitImage(Image image)
            {
                Console.WriteLine("Image");
            }
        }

        // Dokumentumfa, amely tartalmazza a különböző dokumentumokat
        class DocumentTree
        {
            private List<IDocumentElement> _elements = new List<IDocumentElement>();

            public void AddElement(IDocumentElement element)
            {
                _elements.Add(element);
            }

            // Egy látogató elfogadása
            public void AcceptVisitor(IVisitor visitor)
            {
                foreach (var element in _elements)
                {
                    element.Accept(visitor);
                }
            }
        }
        public class Program
        {
            public static void Main(string[] args)
            {
                var documentTree = new DocumentTree();
                documentTree.AddElement(new TextDocument());
                documentTree.AddElement(new Image());

                var printer = new DocumentPrinter();
                documentTree.AcceptVisitor(printer);
            }
        }
    }
}
