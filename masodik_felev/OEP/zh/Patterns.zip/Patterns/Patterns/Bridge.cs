﻿//Author: Leszkovszky Alexandra
//Date: 2022.03.28

namespace Patterns
{
    public class Bridge
    {
        //Híd:
        //Szétválasztjuk az absztrakciót az implementációtól, így nem függenek egymástól és külön-külön módosítani lehet őket

        //Példa:
        //Van 2 különböző autó fajtát implementáló osztály, 2 külön "Drive()" megvalósítással. Ezen kívül van egy Autó osztály, ami definiálja
        //a továbbfejlesztett Drive metódust -> DriveCar
        //Így az ebből származtatott általánosított osztály (Jármű) ezt tudja implementálni.

        //Miért használnánk ezt a mintát:
        //A valóéletben, ez sokszor alkalmazott minta, hiszen mindig törekszünk adott alkalmazás-rétegeket/funkció-csoportokat szétválasztani úgy,
        //hogy ezek ne függjenek egymástól. Az így implementált osztályokat tudjuk úgy bővíteni és múdosítani, hogy az absztakció ne változzon, és vise-versa.
        interface ICarImplementation //impementáció
        {
            void Drive();
        }

        class SedanImplementation : ICarImplementation //konkrét implementáció
        {
            public void Drive()
            {
                Console.WriteLine("Driving a sedan car");
            }
        }

        class SUVImplementation : ICarImplementation
        {
            public void Drive()
            {
                Console.WriteLine("Driving an SUV");
            }
        }

        abstract class Car //absztakció
        {
            protected ICarImplementation _implementation;

            public Car(ICarImplementation implementation)
            {
                _implementation = implementation;
            }

            public abstract void DriveCar();
        }

        class Vehicle : Car //finomított absztrakció
        {
            public Vehicle(ICarImplementation implementation) : base(implementation)
            {
            }

            public override void DriveCar()
            {
                Console.Write("Driving: ");
                _implementation.Drive();
            }
        }
        public class Program
        {
            public static void Main(string[] args)
            {
                var vehicle = new Vehicle(new SUVImplementation());
                vehicle.DriveCar();
            }
        }
    }
}
