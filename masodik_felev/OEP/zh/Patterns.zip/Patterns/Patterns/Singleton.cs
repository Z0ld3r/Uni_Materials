﻿//Author: Leszkovszky Alexandra
//Date: 2022.03.28

namespace Patterns
{
    class Singleton
    {
        //Egyke:
        //Biztosítja, hogy egy osztályból csak egyetlen példány létezzen a program futása során, és ezt a példányt globálisan elérhessük.

        //Példa:
        //A Singleton osztály egy privát konstruktort használ, hogy megakadályozza új példányok létrehozását kívülről.
        //Az Instance property egy statikus példányt tárol, és ha még nincs példány, akkor létrehozza azt.
        //A ShowMessage() metódus bizonyítja, hogy az egyetlen példány működik.

        //Miért használnánk ezt a mintát:
        //Globális állapotok kezelésére (pl.konfigurációs beállítások, naplózás).
        //Vagy, ha egy erőforrásigényes objektumból csak egy példány szükséges (pl.adatbázis kapcsolat).
        //Illetve biztosítja, hogy minden hivatkozás ugyanarra az egyetlen objektumra mutasson.

        private static Singleton? instance;

        private Singleton() { } // Privát konstruktor

        public static Singleton Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Singleton();
                }
                return instance;
            }
        }// Property-ként megvalósítva az elérhetőség

        //public static Singleton Instance()
        //{
        //    if (instance == null)
        //    {
        //        instance = new Singleton();
        //    }
        //    return instance;
        //} Metódusként megvalósítva az elérhetőség

        public void ShowMessage()
        {
            Console.WriteLine("I am a Singleton instance!");
        }
        public class Program
        {
            static void Main()
            {
                Singleton s1 = Singleton.Instance;
                Singleton s2 = Singleton.Instance;

                s1.ShowMessage();

                Console.WriteLine(ReferenceEquals(s1, s2)); // true (ugyanaz az instance)
            }
        }
    }
}
