﻿//Author: Leszkovszky Alexandra
//Date: 2022.03.28

namespace Patterns
{
    public class Strategy
    {
        //Stratégia:
        //Létrehozunk több féle algoritmust, avagy implementációt, ugyanarra a problémára. Ezek ugyanazt a problémát oldják meg, és habár hasonlóak,
        //eltérnek egymástól. A lényege a mintának, hogy futásidőben választja ki, hogy melyik algoritmus fusson le a sok közül.

        //Példa:
        //Egy kávézóban 2-féleképpen tudják elkészíteni a kávét. De azt szeretnénk, hogy ne előre megszabott módon legyen elkészítve a vendég rendelése,
        //hanem akkor válassza ki, amikor a vengéd rendel, hiszen akkor derül ki, hogy melyiket szeretné.

        //Miért használnánk ezt a mintát:
        //Az első, ami észrevehető, az az, hogy ezt sokkal egyszerűbben is meg lehet oldani (pl. egy ősosztállyal)
        //Ez teljesen így van. A stratégia ránézésre csak az OOP polimorfizmus tulajdonsága, de ez nem teljesen így van.
        //HASZNÁLJA a polimorfizmust, de egy speciális esete a polimorfizmus felhasználásának.
        //Ez a minta arra van, hogy egy adott osztálytól ELKÜLÖNÍTSÜNK egy adott funkciót/stratégiát. Ezzel védve az Open/closed elvet.
        //Hiszen azt szeretnénk, hogy ha bővülne a stratégiák listája, ne kelljen belenyúlni az eredeti osztályba, elég az elkülönített részt bővíteni. 
        interface IBrewingStrategy
        {
            void Brew();
        }

        class DripCoffeeStrategy : IBrewingStrategy
        {
            public void Brew()
            {
                Console.WriteLine("Brewing coffee using drip method");
            }
        }

        class FrenchPressStrategy : IBrewingStrategy
        {
            public void Brew()
            {
               Console.WriteLine("Brewing coffee using French press method");
            }
        }

        class CoffeeMaker
        {
            private IBrewingStrategy _strategy;

            public CoffeeMaker(IBrewingStrategy strategy) //ő fogja eldönteni, hogy mit kell használni
            {
                _strategy = strategy;
            }

            public void BrewCoffee()//alkalmazza a megfelelő stratégiát
            {
                _strategy.Brew();
            }
        }
        public class Program
        {
            public static void Main(string[] args)
            {
                IBrewingStrategy strategy = new DripCoffeeStrategy();
                CoffeeMaker coffeeMaker=new CoffeeMaker(strategy);
            }
        }
    }
}
