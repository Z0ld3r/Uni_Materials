﻿//Author: Leszkovszky Alexandra
//Date: 2022.03.28

namespace Patterns
{
    public class Factory
    {
        //Gyártófüggvény:
        //Az egyes osztályok döntik el, hogy melyik osztály példányosítását hajtják végre, míg az objektum létrehozásához egy interfészt definiálunk.
        //A minta lehetővé teszi egy osztály számára, hogy a példányosítást az al-osztályokra halassza.

        //Példa:
        //Egy játékban 2 féle karakter van, ezek implementálják az Attack metódust. A gyártó, létrehozza a megfelelő típusú objektumot.

        //Miért használnánk ezt a mintát:
        //A gyár minta segít az objektumok létrehozásában anélkül, hogy közvetlenül hivatkoznánk a konkrét osztályokra.
        //Akkor használjuk, ha a származtatott osztályoknak nem szükséges tudnia, hogy egy adott objektum hogyan inicializálódik.

        // Különböző játékfigurák
        interface ICharacter
        {
            void Attack();
        }

        class Warrior : ICharacter
        {
            public void Attack()
            {
                Console.WriteLine("Warrior attacks with a sword");
            }
        }

        class Mage : ICharacter
        {
            public void Attack()
            {
                Console.WriteLine("Mage casts a fireball");
            }
        }

        interface ICharacterFactory //metódust deklarál, mely később létrehozza a példányt
        {
            ICharacter CreateCharacter();
        }

        class WarriorFactory : ICharacterFactory //példányosítanak
        {
            public ICharacter CreateCharacter()
            {
                return new Warrior();
            }
        }

        class MageFactory : ICharacterFactory
        {
            public ICharacter CreateCharacter()
            {
                return new Mage();
            }
        }
        public class Program
        {
            public static void Main(string[] args)
            {
                ICharacterFactory factory = new MageFactory();
                ICharacter character = factory.CreateCharacter();
                character.Attack();
            }
        }
    }
}
