﻿namespace Exhibition;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("A teszteket a fejlesztőkörnyezet egységtesztjeivel lehet futtatni.");
    }
}