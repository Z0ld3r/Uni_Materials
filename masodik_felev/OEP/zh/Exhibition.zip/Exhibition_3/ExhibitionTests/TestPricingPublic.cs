using Exhibition;

namespace ExhibitionTests;

[TestClass]
[TestCategory("TestPricing")]
public class TestPricingPublic
{
    private Artist batman = null!;

    [TestInitialize]
    public void TestInit()
    {
        batman = new Artist("Bruce Wayne");
    }

    [DataTestMethod]
    [DataRow(1950, 195000000.0)]
    [DataRow(1848, 462000000.0)]
    public void TestRegular(int year, double expected)
    {
        Artwork[] artworks =
        {
            new Painting("grease", batman, 123, "Hajnali szarnyalas", year, new RegularPricing()),
        };

        foreach (Artwork artwork in artworks)
        {
            Assert.AreEqual(expected, artwork.CalculatePrice());
        }
    }

    [DataTestMethod]
    [DataRow(1950, 194995000.0)]
    [DataRow(1848, 461995000.0)]
    public void TestDiscount(int year, double expected)
    {
        Artwork[] artworks = {
            new Painting("grease", batman, 123, "Hajnali szarnyalas", year, new DiscountPricing()),
        };

        foreach (Artwork artwork in artworks)
        {
            Assert.AreEqual(expected, artwork.CalculatePrice());
        }
    }

    [TestMethod]
    public void TestPremium()
    {
        Assert.AreEqual(180000.0,
            new Painting("grease", batman, 123, "Hajnali szarnyalas", 1, new PremiumPricing()).CalculatePrice());
        Assert.AreEqual(180000.0,
            new Painting("marble", batman, 156, "title", 1, new PremiumPricing()).CalculatePrice());
        Assert.AreEqual(250000.0, 
            new Painting("oil", batman, 155, "Megesik", 1, new PremiumPricing()).CalculatePrice());

        Assert.AreEqual(180000.0,
            new Sculpture("grease", batman, 123, "", 1, new PremiumPricing()).CalculatePrice());
        Assert.AreEqual(180000.0,
            new Sculpture("oil", batman, 155, "Maybe", 1, new PremiumPricing()).CalculatePrice());
        Assert.AreEqual(1050000.0,
            new Sculpture("marble", batman, 156, "Pic", 1, new PremiumPricing()).CalculatePrice());
    }
}