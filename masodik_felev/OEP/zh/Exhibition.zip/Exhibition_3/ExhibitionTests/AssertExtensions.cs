using System.Reflection;
using Exhibition;

namespace ExhibitionTests;

public static class AssertExtensions
{
    public static void Catch<Ex>(this Assert ass, Action action, string? message = null) where Ex : Exception
    {
        try
        {
            action.Invoke();
        }
        catch (NullReferenceException)
        {
            throw;
        }
        catch (ArgumentOutOfRangeException)
        {
            throw;
        }
        catch (IndexOutOfRangeException)
        {
            throw;
        }
        catch (Ex)
        {
            return;
        }
        catch (Exception e)
        {
            Assert.Fail($"Unexpected exception (wanted {typeof(Ex).FullName}): {e}");
        }

        Assert.Fail(message ?? $"No {typeof(Ex).FullName} or derivative thrown.");
    }

    public static void HasProperty<T>(this Assert ass, string propName, bool hasPublicGetter, bool hasPublicSetter, string? message = null)
    {
        PropertyInfo? prop =
            typeof(T).GetProperty(propName, BindingFlags.Public | BindingFlags.Instance);
        Assert.IsNotNull(prop, $"{propName} should exist as a property");
        Assert.AreEqual(hasPublicGetter, prop.GetMethod?.IsPublic ?? false, message ?? $"{propName} getter {(hasPublicGetter ? "should" : "should not")} be public");
        Assert.AreEqual(hasPublicSetter, prop.SetMethod?.IsPublic ?? false, message ?? $"{propName} setter {(hasPublicSetter ? "should" : "should not")} be public");
    }

    public static void HasMethod<T>(this Assert ass, string methodName, BindingFlags bindingFlags = BindingFlags.Default, string? message = null)
    {
        MethodInfo? search =
            typeof(T).GetMethod(methodName, bindingFlags);
        Assert.IsNotNull(search, message ?? $"{methodName} missing");
    }
}