using Exhibition;

namespace ExhibitionTests;

[TestClass]
[TestCategory("TestExhibition")]
public class TestExhibitionPublic
{
    [TestMethod]
    public void TestExhibitArtworkGood()
    {
        List<StatCatalog> cats = new List<StatCatalog>{new StatCatalog()};
        Exhibition.Exhibition ex = new Exhibition.Exhibition("exhib", DateTime.Today, 5, cats);
        Artwork aw = new Painting("crayons", new Artist("Joe"), 2, "My house", 1994, new DiscountPricing());
        ex.ExhibitArtwork(aw);
        Artwork[] aws = new[] { aw };
        CollectionAssert.AreEqual(aws, cats[0].GetArtworks(), "Catalog updated incorrectly");
        CollectionAssert.AreEqual(aws, ex.Artworks);
    }
    
    [TestMethod]
    public void TextExhibitArtworkArtistFull()
    {
        List<StatCatalog> cats = new List<StatCatalog>{new StatCatalog()};
        Exhibition.Exhibition ex = new Exhibition.Exhibition("exhib", DateTime.Today, 200, cats);
        List<Artwork> aws = new List<Artwork>();
        Artist joe = new Artist("Joe");
        for (int i = 0; i < 5; ++i)
        {
            Artwork aw = new Painting("crayons", joe, 2, "My house", 1994, new DiscountPricing());
            ex.ExhibitArtwork(aw);
            aws.Add(aw);
        }
        
        ex.ExhibitArtwork(new Sculpture("concrete", joe, 3, "Your house", 2048, new PremiumPricing()));
        CollectionAssert.AreEqual(aws, cats[0].GetArtworks(), "Catalog updated incorrectly");
        CollectionAssert.AreEqual(aws, ex.Artworks);
    }
    
    [TestMethod]
    public void TextExhibitArtworkLimitFull()
    {
        List<StatCatalog> cats = new List<StatCatalog>{new StatCatalog()};
        Exhibition.Exhibition ex = new Exhibition.Exhibition("exhib", DateTime.Today, 4, cats);
        List<Artwork> aws = new List<Artwork>();
        Artist joe = new Artist("Joe");
        for (int i = 0; i < 4; ++i)
        {
            Artwork aw = new Painting("crayons", joe, 2, "My house", 1994, new DiscountPricing());
            ex.ExhibitArtwork(aw);
            aws.Add(aw);
        }
        CollectionAssert.AreEqual(aws, cats[0].GetArtworks(), "Catalog updated incorrectly");
        CollectionAssert.AreEqual(aws, ex.Artworks);
        
        Sculpture sc = new Sculpture("concrete", new Artist("Not Joe"), 3, "Your house", 2048, new PremiumPricing());
        ex.ExhibitArtwork(sc);
        CollectionAssert.AreEqual(aws, cats[0].GetArtworks(), "Catalog updated incorrectly");
        CollectionAssert.AreEqual(aws, ex.Artworks);
    }
    
    [TestMethod]
    public void TestExhibitArtworkBad()
    {
        Artwork aw1 = new Sculpture("stone", new Artist("Jack"), 241, "Bad times", 2222, new RegularPricing());
        Exhibition.Exhibition ex =
            new Exhibition.Exhibition("Exhibition", DateTime.MaxValue, 10, new List<StatCatalog>());
        ex.ExhibitArtwork(aw1);
        CollectionAssert.AreEqual(new[]{aw1}, ex.Artworks);
        Assert.That.Catch<Exception>(() => ex.ExhibitArtwork(aw1));
        CollectionAssert.AreEqual(new[]{aw1}, ex.Artworks);
    }
    
    [TestMethod]
    public void TestMultipleCatalogs()
    {
        List<StatCatalog> cats = Enumerable.Repeat(0, 5).Select(_ => new StatCatalog()).ToList();
        Exhibition.Exhibition[] exes =
        {
            new("ex1", DateTime.MinValue, 8, cats),
            new("ex2", DateTime.UtcNow, 7, cats),
            new("ex3", DateTime.Today, 9, cats),
        };
        List<Artwork> aws = new List<Artwork>();
        for (int i = 0; i < 7; ++i)
        {
            foreach (Exhibition.Exhibition ex in exes)
            {
                Artwork art = new Sculpture("brick", new Artist("Baker"), 24, "Good times", 1997, new RegularPricing());
                ex.ExhibitArtwork(art);
                aws.Add(art);   
            }
        }
        exes[1].ExhibitArtwork(new Painting("none", new Artist("Robin"), 7, "Bad times", 2210651, new DiscountPricing()));
        cats.ForEach(cat => CollectionAssert.AreEqual(aws, cat.GetArtworks()));
    }
}