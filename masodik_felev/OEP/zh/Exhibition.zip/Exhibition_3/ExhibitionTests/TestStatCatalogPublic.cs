using System.Reflection;
using Exhibition;

namespace ExhibitionTests;

[TestClass]
[TestCategory("TestStatCatalog")]
public class TestStatCatalogPublic
{
    public static IEnumerable<object?[]> ExpensiveSculptureData
    {
        get
        {
            yield return new object?[] { "No artworks", null, new Artwork[] {} };
            yield return new object?[]
            {
                "Multiple sculptures", "Sculptor", new Artwork[]
                {
                    new Painting("oil", new Artist("Joe"), 23, "asd", 20000, new PremiumPricing()),
                    new Sculpture("asd", new Artist("Sculptor2"), 23, "asd", 2, new DiscountPricing()),
                    new Painting("asd", new Artist("Joe"), 23, "asd", 2, new DiscountPricing()),
                    new Sculpture("asd", new Artist("Sculptor"), 23, "asd", 2, new RegularPricing()),
                    new Sculpture("asd", new Artist("Sculptor2"), 23, "asd", 2, new DiscountPricing()),
                }
            };
        }
    }

    [DataTestMethod]
    [DynamicData(nameof(ExpensiveSculptureData), DynamicDataDisplayName = nameof(GetDynamicDataDisplayNames))]
    public void TestArtistOfMostExpensiveSculpture(string humanReadableName, string? expectedArtist, IEnumerable<Artwork> artworks)
    {
        StatCatalog cat = new StatCatalog();
        foreach (Artwork artwork in artworks)
        {
            cat.Update(artwork);
        }
        if(expectedArtist == null) Assert.IsFalse(cat.GetArtistOfMostExpensiveSculpture().Item1, "There should be no artist");
        else
        {
            (bool found, Artist? artist) = cat.GetArtistOfMostExpensiveSculpture();
            Assert.IsTrue(found);
            Assert.AreEqual(expectedArtist, artist?.Name);
        }
    }
    
    public static IEnumerable<object?[]> OldestArtworkData
    {
        get
        {
            yield return new object?[] { "No art", null, new Artwork[] { } };
            yield return new object?[]
            {
                "Multiple", "the_sculpture", new Artwork[]
                {
                    new Painting("asd", new Artist(""), 2, "the_painting", 256, new DiscountPricing()),
                    new Painting("asd", new Artist(""), 2, "the_painting", 135, new DiscountPricing()),
                    new Sculpture("asd", new Artist(""), 4, "the_sculpture", -2, new PremiumPricing()),
                    new Painting("asd", new Artist(""), 2, "the_painting", 1425, new PremiumPricing()),
                }
            };
        }
    }
    
    [DataTestMethod]
    [DynamicData(nameof(OldestArtworkData), DynamicDataDisplayName = nameof(GetDynamicDataDisplayNames))]
    public void TestOldestArtwork(string humanReadableName, string? expectedArtwork, IEnumerable<Artwork> artworks)
    {
        StatCatalog cat = new StatCatalog();
        foreach (Artwork artwork in artworks)
        {
            cat.Update(artwork);
        }
        if(expectedArtwork == null) Assert.That.Catch<Exception>(() => cat.OldestArtwork(), "No exception thrown");
        else Assert.AreEqual(expectedArtwork, cat.OldestArtwork().Title);
    }
    
    public static IEnumerable<object?[]> TotalValueData
    {
        get
        {
            yield return new object?[] { "No art", 0.0, new Artwork[] { } };
            yield return new object?[]
            {
                "There is art", 1300000.0, new Artwork[]
                {
                    new Painting("oil", new Artist(""), 5, "painting", 1, new RegularPricing()),
                    new Sculpture("marble", new Artist(""), 5, "painting", 1, new PremiumPricing()),
                }
            };
        }
    }

    [DataTestMethod]
    [DynamicData(nameof(TotalValueData), DynamicDataDisplayName = nameof(GetDynamicDataDisplayNames))]
    public void TestCalculateTotalValue(string humanReadableName, double expectedValue, IEnumerable<Artwork> artworks)
    {
        StatCatalog cat = new StatCatalog();
        foreach (Artwork artwork in artworks)
        {
            cat.Update(artwork);
        }
        Assert.AreEqual(expectedValue, cat.CalculateTotalValue());
    }

    public static IEnumerable<object?[]> CountPaintingsData
    {
        get
        {
            yield return new object?[] { "No art", "whatever", 0, new Artwork[] { } };
            yield return new object?[]
            {
                "No valid marbles", "marble", 0, new Artwork[]
                {
                    new Sculpture("marble", new Artist(""), 2, "title", 212, new PremiumPricing()),
                    new Sculpture("brick", new Artist(""), 2, "title", 212, new PremiumPricing()),
                    new Painting("marbel", new Artist(""), 5, "title", 251, new DiscountPricing()),
                    new Sculpture("marble", new Artist(""), 2, "title", 212, new PremiumPricing()),
                }
            };
            yield return new object?[]
            {
                "There are paintings", "crayons", 2, new Artwork[]
                {
                    new Sculpture("marble", new Artist(""), 2, "title", 212, new PremiumPricing()),
                    new Painting("crayons", new Artist(""), 4, "", 2, new RegularPricing()),
                    new Sculpture("crayons", new Artist(""), 2, "title", 212, new PremiumPricing()),
                    new Painting("crayonsa", new Artist(""), 4, "", 2, new RegularPricing()),
                    new Painting("crayons", new Artist(""), 4, "", 2, new RegularPricing()),
                    new Painting("oil", new Artist(""), 5, "title", 31, new RegularPricing()),
                }
            };
        }
    }
    
    [DataTestMethod]
    [DynamicData(nameof(CountPaintingsData), DynamicDataDisplayName = nameof(GetDynamicDataDisplayNames))]
    public void TestCountPaintings(string humanReadableName, string selector, int expectedValue,
        IEnumerable<Artwork> artworks)
    {
        StatCatalog cat = new StatCatalog();
        foreach (Artwork artwork in artworks)
        {
            cat.Update(artwork);
        }
        Assert.AreEqual(expectedValue, cat.CountPaintings(selector));
    }
    
    public static string GetDynamicDataDisplayNames(MethodInfo method, object?[] values)
    {
        return (string)values[0]! + $" ({method.Name})";
    }
}