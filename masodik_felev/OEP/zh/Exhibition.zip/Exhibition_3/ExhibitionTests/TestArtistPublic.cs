using System.Reflection;
using Exhibition;

namespace ExhibitionTests;

[TestClass]
[TestCategory("TestArtist")]
public class TestArtistPublic
{
    private Artist batman = null!;
    
    [TestInitialize]
    public void TestInit()
    {
        batman = new Artist("Bruce Wayne");
    }
    
    [DataTestMethod]
    [DataRow("oil", 12, "", -1215, nameof(PremiumPricing))]
    public void TestPaint(string type, int id, string title, int year, string pricingStrategy)
    {
        Assembly exhib = Assembly.GetAssembly(typeof(IPricingStrategy))!;
        Type ps = exhib.GetType("Exhibition." + pricingStrategy)!;
        IPricingStrategy strategy = (IPricingStrategy)Activator.CreateInstance(ps)!;
        batman.Paint(type, id, title, year, strategy);
        Assert.AreEqual(1, batman.Artworks.Count, $"{nameof(Artist.Paint)} should only paint once");
        Assert.IsTrue(batman.Artworks[0] is Painting, $"{nameof(Artist.Paint)} should create paintings");
        Assert.AreEqual(type, ((Painting)batman.Artworks[0]).PaintType);
        Assert.AreEqual(id, batman.Artworks[0].Id);
        Assert.AreEqual(title, batman.Artworks[0].Title);
        Assert.AreEqual(year, batman.Artworks[0].Year);
        Assert.AreEqual(strategy.Calculate(batman.Artworks[0]), batman.Artworks[0].CalculatePrice());
    }
    
    [DataTestMethod]
    [DataRow("concrete", 24, "Magyar népmesék", 1645, nameof(RegularPricing))]
    public void TestSculpt(string type, int id, string title, int year, string pricingStrategy)
    {
        Assembly exhib = Assembly.GetAssembly(typeof(IPricingStrategy))!;
        Type ps = exhib.GetType("Exhibition." + pricingStrategy)!;
        IPricingStrategy strategy = (IPricingStrategy)Activator.CreateInstance(ps)!;
        batman.Sculpt(type, id, title, year, strategy);
        Assert.AreEqual(1, batman.Artworks.Count, $"{nameof(Artist.Sculpt)} should only sculpt once");
        Assert.IsTrue(batman.Artworks[0] is Sculpture, $"{nameof(Artist.Sculpt)} should create sculptures");
        Assert.AreEqual(type, ((Sculpture)batman.Artworks[0]).Material);
        Assert.AreEqual(id, batman.Artworks[0].Id);
        Assert.AreEqual(title, batman.Artworks[0].Title);
        Assert.AreEqual(year, batman.Artworks[0].Year);
        Assert.AreEqual(strategy.Calculate(batman.Artworks[0]), batman.Artworks[0].CalculatePrice());
    }
    
    [TestMethod]
    public void TestExhibitArtwork()
    {
        batman.Paint("oil", 2, "Painting", 2002, new PremiumPricing());
        batman.Sculpt("concrete", 4, "Brick", 1996, new RegularPricing());
        batman.Paint("concrete", 2, "Brick", 1996, new RegularPricing());

        batman.ExhibitArtwork("Brick",
            new Exhibition.Exhibition("Exhibition1", DateTime.UnixEpoch, 5, new List<StatCatalog>()));
        CollectionAssert.AreEqual(new bool[] { false, true, false },
            batman.Artworks.Select(aw => aw.IsOnExhibition).ToArray());

        Assert.That.Catch<Exception>(
            () => batman.ExhibitArtwork("Brickie",
                new Exhibition.Exhibition("Exhibition1", DateTime.UnixEpoch, 5, new List<StatCatalog>())),
            "Unknown artworks should get an exception");
    }
    
    [TestMethod]
    public void TestIsEverythingOnExhibition()
    {
        batman.Paint("oil", 2, "pa", 2022, new RegularPricing());
        batman.Sculpt("plastic", 3, "sc", 2022, new RegularPricing());
        Assert.IsFalse(batman.IsEverythingOnExhibition(), "Two works not on exhibition");
        batman.ExhibitArtwork("sc", new Exhibition.Exhibition("e1", DateTime.Now, 2, new List<StatCatalog>()));
        Assert.IsFalse(batman.IsEverythingOnExhibition(), "Not all works are on exhibition");
        batman.ExhibitArtwork("pa", new Exhibition.Exhibition("e1", DateTime.Now, 2, new List<StatCatalog>()));
        Assert.IsTrue(batman.IsEverythingOnExhibition(), "All works are on exhibition now");
    }
}