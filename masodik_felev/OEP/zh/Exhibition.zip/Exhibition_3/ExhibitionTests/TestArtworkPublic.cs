using Exhibition;

namespace ExhibitionTests;

[TestClass]
[TestCategory("TestArtwork")]
public class TestArtworkPublic
{
    private Artist batman = null!;

    [TestInitialize]
    public void TestInit()
    {
        batman = new Artist("Bruce Wayne");
    }
    
    [TestMethod]
    public void TestPainting()
    {
        Painting painting = new Painting("crayons", batman, 24, "interesting_title", -13545, new PremiumPricing());
        Assert.AreEqual("crayons", painting.PaintType);
        Assert.AreEqual(batman, painting.Artist);
        Assert.AreEqual(24, painting.Id);
        Assert.AreEqual(-13545, painting.Year);
        Assert.AreEqual(new PremiumPricing().Calculate(painting), painting.CalculatePrice());
    }

    [TestMethod]
    public void TestSculpture()
    {
        Sculpture sculpture = new Sculpture("sand", batman, 56, "scuplture", 5343, new PremiumPricing());
        Assert.AreEqual("sand", sculpture.Material);
        Assert.AreEqual(batman, sculpture.Artist);
        Assert.AreEqual(56, sculpture.Id);
        Assert.AreEqual(5343, sculpture.Year);
        Assert.AreEqual(new PremiumPricing().Calculate(sculpture), sculpture.CalculatePrice());
    }
}