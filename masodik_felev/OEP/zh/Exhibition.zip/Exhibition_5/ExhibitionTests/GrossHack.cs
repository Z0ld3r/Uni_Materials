using System.Collections;
using System.Reflection;
using Exhibition;

namespace ExhibitionTests;

public static class GrossHack
{
    // no gross hacks here, sorry
    public static ICollection? GetArtworks(this StatCatalog statCat)
    {
        FieldInfo? artworks = typeof(StatCatalog).GetFields(BindingFlags.Instance | BindingFlags.NonPublic)
            .FirstOrDefault((FieldInfo info) => info.FieldType.GetInterfaces().Contains(typeof(ICollection<Artwork>)));
        Assert.IsNotNull(artworks, "No artworks stored in StatCatalog");
        return artworks.GetValue(statCat) as ICollection;
    }
    
    public static ICollection<Artist>? GetArtists(this ArtistCatalog arCat)
    {
        FieldInfo? artists = typeof(ArtistCatalog).GetFields(BindingFlags.Instance | BindingFlags.NonPublic)
            .FirstOrDefault((FieldInfo info) => info.FieldType.GetInterfaces().Contains(typeof(ICollection<Artist>)));
        Assert.IsNotNull(artists, "No artists stored in ArtistCatalog");
        return artists.GetValue(arCat) as ICollection<Artist>;
    }

    public static (bool, Artist?) GetArtistOfMostExpensiveSculpture(this StatCatalog statCat)
    {
        return statCat.TranslateBoolXType<StatCatalog, Artist?>(nameof(StatCatalog.ArtistOfMostExpensiveSculpture),
            AllowedSignatures.ReturnNullable | AllowedSignatures.BothOutParam | AllowedSignatures.OutParamNullable |
            AllowedSignatures.ReturnBoolOutParam | AllowedSignatures.ReturnTuple, BindingFlags.Instance | BindingFlags.Public,
            new Type[] { });
    }

    private static (bool, TReturn) TranslateBoolXType<TObject, TReturn>(this TObject obj, string methodName, AllowedSignatures allowedSignatures, BindingFlags bindingFlags, Type[] argTypes, params object?[] paramList)
    {
        Type[] realArgTypes = argTypes.ToArray();
        MethodInfo? method = typeof(TObject).GetMethod(methodName, bindingFlags, realArgTypes);
        if ((allowedSignatures & AllowedSignatures.ReturnNullable) != 0 && method != null && method.ReturnType == typeof(TReturn))
        {
            TReturn? retval = (TReturn?)method.Invoke(obj, paramList);
            return (retval != null, retval!);
        } 
        if ((allowedSignatures & AllowedSignatures.ReturnTuple) != 0 && method != null)
        {
            if (method.ReturnType == typeof(ValueTuple<bool, TReturn>))
            {
                return (ValueTuple<bool, TReturn>)method.Invoke(obj, paramList)!;
            }
            if (method.ReturnType == typeof(Tuple<bool, TReturn>))
            {
                return ((Tuple<bool, TReturn>)method.Invoke(obj, paramList)!).ToValueTuple();
            }
        }
        
        realArgTypes = argTypes.Concat(new[] { typeof(TReturn).MakeByRefType() }).ToArray();
        method = typeof(TObject).GetMethod(methodName, bindingFlags, realArgTypes);
        if ((allowedSignatures & AllowedSignatures.OutParamNullable) != 0 && method != null && method.ReturnType == typeof(void))
        {
            object?[] realParamList = paramList.Concat(new object?[] { null }).ToArray();
            method.Invoke(obj, realParamList);
            return (realParamList[^1] != null, (TReturn)realParamList[^1]!);
        }

        realArgTypes = argTypes.Concat(new[] { typeof(TReturn).MakeByRefType() }).ToArray();
        method = typeof(TObject).GetMethod(methodName, bindingFlags, realArgTypes);
        if ((allowedSignatures & AllowedSignatures.ReturnBoolOutParam) != 0 && method != null && method.ReturnType == typeof(bool))
        {
            object?[] realParamList = paramList.Concat(new object?[] { null }).ToArray();
            bool result = (bool)method.Invoke(obj, realParamList)!;
            return (result, (TReturn)realParamList[^1]!);
        }
        
        realArgTypes = argTypes.Concat(new[] { typeof(bool).MakeByRefType(), typeof(TReturn).MakeByRefType() }).ToArray();
        method = typeof(TObject).GetMethod(methodName, bindingFlags, realArgTypes);
        if ((allowedSignatures & AllowedSignatures.BothOutParam) != 0 && method != null && method.ReturnType == typeof(void))
        {
            object?[] realParamList = paramList.Concat(new object?[] { false, null }).ToArray();
            method.Invoke(obj, realParamList);
            return ((bool)realParamList[^2]!, (TReturn)realParamList[^1]!);
        }
        
        throw new NotSupportedException("Unknown calling convention");
    }

    [Flags]
    private enum AllowedSignatures
    {
        ReturnNullable = 1 << 0,
        OutParamNullable = 1 << 1,
        ReturnBoolOutParam = 1 << 2,
        BothOutParam = 1 << 3,
        ReturnTuple = 1 << 4,
    }
}
