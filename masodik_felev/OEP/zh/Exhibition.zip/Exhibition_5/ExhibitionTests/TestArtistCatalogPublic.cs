using System.Reflection;
using Exhibition;

namespace ExhibitionTests;

[TestClass]
[TestCategory("TestArtistCatalog")]
public class TestArtistCatalogPublic
{
    [TestMethod]
    public void TestUpdate()
    {
        ArtistCatalog ac = new ArtistCatalog();
        string[] artists = { "Joe", "Bill", };
        for (int i = 0; i < artists.Length; ++i)
        {
            for (int j = 0; j <= 3; ++j)
            {
                ac.Update(new Painting("whatever", new Artist(artists[i]), i * j, "Cool painting", 1989,
                    new DiscountPricing()));
            }
        }

        CollectionAssert.AreEqual(artists, ac.GetArtists()?.Select(a => a.Name).ToArray(),
            $"{nameof(ArtistCatalog.Update)} should add everyone exactly once");
    }

    public static IEnumerable<object?[]> ExpensiveArtworkData
    {
        get
        {
            yield return new object?[] { "No artworks", null, new (string, int)[] {} };
            yield return new object?[]
            {
                "Repeats", "the_one", new (string, int)[]
                {
                    ("a", 5),
                    ("b", 3),
                    ("the_one", 9),
                    ("the_two", 9),
                    ("d", 8),
                }
            };
        }
    }

    [DataTestMethod]
    [DynamicData(nameof(ExpensiveArtworkData), DynamicDataDisplayName = nameof(GetDynamicDataDisplayNames))]
    public void TestMostExpensiveArtworkByArtist(string humanReadableName, string? expectedArtwork, IEnumerable<(string, int)> artworks)
    {
        ArtistCatalog ac = new ArtistCatalog();
        
        Artist artist = new Artist("");
        foreach ((string title, int year) in artworks)
        {
            artist.Paint("crayons", 123, title, year, new RegularPricing());
        }
        
        if(expectedArtwork == null) Assert.That.Catch<Exception>(() => ac.MostExpensiveArtworkByArtist(artist));
        else Assert.AreEqual(expectedArtwork, ac.MostExpensiveArtworkByArtist(artist)?.Title);
    }
    
    public static string GetDynamicDataDisplayNames(MethodInfo method, object?[] values)
    {
        return (string)values[0]! + $" ({method.Name})";
    }
}