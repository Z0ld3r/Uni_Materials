namespace ExhibitionTests;

[TestClass]
[TestCategory("TestIExhibitionCatalog")]
public class TestIExhibitionCatalogPublic
{
    
}