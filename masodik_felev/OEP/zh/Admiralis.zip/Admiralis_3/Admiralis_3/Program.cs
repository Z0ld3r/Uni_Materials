﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace Admiralis_3
{
    internal class Program
    {
        private sealed class FrameworkException(string message) : Exception(message);
        
        static void Main(string[] args)
        {
            string inputPath = args.Length == 0 ? "input.txt" : args[0];

            using IEnumerator<string> lines = File.ReadLines(inputPath).GetEnumerator();

            if (!lines.MoveNext()) throw new FrameworkException("Üres bemenet.");

            switch (lines.Current)
            {
                case "szimulacio":
                    TestSimulation(lines);
                    break;
                case "csata":
                    TestBattle(lines);
                    break;
                case "hajo":
                    TestShips(lines);
                    break;
            }
        }

        private static void TestSimulation(IEnumerator<string> lines)
        {
            List<Bolygo> planets = new List<Bolygo>();
            Szimulacio simulation = new Szimulacio();
            while (lines.MoveNext())
            {
                string[] data = lines.Current.Split(new char[] { ' ', '\t' }, 
                    StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
                try
                {
                    switch (data[0])
                    {
                        case "futtat":
                            simulation.Futtat(int.Parse(data[1]));
                            Console.WriteLine($"{data[1]} kör futtatása...");
                            break;
                        case "csata":
                            Bolygo planet = planets.Find(p => p.Nev == data[1]) ??
                                            new Bolygo(data[1], int.Parse(data[2]));
                            if (!planets.Contains(planet)) planets.Add(planet);
                            Frakcio faction = data[3] == "szakadar" ? Frakcio.Szakadarok : Frakcio.Koztarsasag;
                            if (!lines.MoveNext()) throw new FrameworkException("Támadó hajó nincs megadva.");
                            Hajo attacker = ParseShip(lines.Current);
                            if (!lines.MoveNext()) throw new FrameworkException("Védő hajó nincs megadva.");
                            Hajo defender = ParseShip(lines.Current);
                            simulation.UjCsata(faction, planet, attacker, defender);
                            Console.WriteLine(
                                $"Új csata: {planet.Nev} ({(faction == Frakcio.Koztarsasag ? "Köztársaság" : "szakadár")})");
                            break;
                        case "erosites":
                            planet = planets.Find(p => p.Nev == data[1]) ?? new Bolygo(data[1], 5);
                            faction = data[2] == "koztarsasag" ? Frakcio.Koztarsasag : Frakcio.Szakadarok;
                            List<Hajo> ships = new List<Hajo>();
                            for (int i = 0; i < int.Parse(data[3]); ++i)
                            {
                                if (!lines.MoveNext()) throw new FrameworkException($"Nincs {data[3]} hajó.");
                                ships.Add(ParseShip(lines.Current));
                            }

                            simulation.Erosites(faction, planet, ships);
                            Console.WriteLine(
                                $"Erősítés a {planet.Nev} ({(faction == Frakcio.Koztarsasag ? "Köztársaság" : "szakadár")})" +
                                $" bolygóra: {ships.Count} hajó.");
                            break;
                        case "gyozelem":
                            faction = data[1] == "koztarsasag" ? Frakcio.Koztarsasag : Frakcio.Szakadarok;
                            Console.WriteLine(
                                $"Elsöprő győzelem a {(faction == Frakcio.Koztarsasag ? "Köztársaság" : "szakadár")} " +
                                $"frakciónak: {simulation.ElsoproGyozelem(faction)?.Nev ?? "nincs"}.");
                            break;
                        case "megsemmisult":
                            Console.WriteLine(
                                $"Megsemmisült hajók a {data[1]} bolygón: {simulation.MegsemmisultHajok(data[1])}");
                            break;
                        default:
                            throw new FrameworkException("Ismeretlen azonosító.");
                    }
                }
                catch (FrameworkException)
                {
                    throw;
                }
                catch
                {
                    Console.WriteLine("Várt vagy váratlan kivétel történt.");
                }
            }
        }

        private static void TestBattle(IEnumerator<string> lines)
        {
            if (!lines.MoveNext()) throw new FrameworkException("A csata alapadatai hiányoznak.");
            string[] data = lines.Current.Split(new char[] { ' ', '\t' }, 
                StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
            Bolygo planet = new Bolygo(data[0], int.Parse(data[1]));
            Frakcio faction = data[2] == "szakadar" ? Frakcio.Szakadarok : Frakcio.Koztarsasag;
            if (!lines.MoveNext()) throw new FrameworkException("Támadó hajó nincs megadva.");
            Hajo attacker = ParseShip(lines.Current);
            if (!lines.MoveNext()) throw new FrameworkException("Védő hajó nincs megadva.");
            Hajo defender = ParseShip(lines.Current);
            Csata battle = new Csata(faction, planet, attacker, defender);
            Console.WriteLine(
                $"Új csata: {planet.Nev} ({(faction == Frakcio.Koztarsasag ? "Köztársaság" : "szakadár")})");
            while (lines.MoveNext())
            {
                data = lines.Current.Split(new char[] { ' ', '\t' },
                    StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
                try
                {
                    switch (data[0])
                    {
                        case "erosites":
                            faction = data[1] == "szakadar" ? Frakcio.Szakadarok : Frakcio.Koztarsasag;
                            if (!lines.MoveNext()) throw new FrameworkException("Hajó hiányzik.");
                            Hajo ship = ParseShip(lines.Current);
                            battle.Erosites(faction, ship);
                            Console.WriteLine(
                                $"Erősítés: {(faction == Frakcio.Koztarsasag ? "Köztársaság" : "szakadár")}");
                            break;
                        case "harc":
                            battle.Harc();
                            Console.WriteLine("Harc a csatatéren");
                            break;
                        case "eredmeny":
                            // a legtöbb értelmes megoldás működni fog a csata.Eredmeny() megvalósítására
                            var res = GetBattleResults(battle,
                                data[1] == "koztarsasag" ? Frakcio.Koztarsasag : Frakcio.Szakadarok);
                            Console.WriteLine($"{(res.Won ? "Nyert" : "Nem nyert")}, maradt {res.Remain} hajója.");
                            break;
                        case "megsemmisult":
                            Console.WriteLine($"Megsemmisült hajók: {battle.MegsemmisultHajok()}");
                            break;
                    }
                }
                catch (FrameworkException)
                {
                    throw;
                }
                catch
                {
                    Console.WriteLine("Várt vagy váratlan hiba történt.");
                }
            }
        }
        
        private static void TestShips(IEnumerator<string> lines)
        {
            while (lines.MoveNext())
            {
                if (!lines.MoveNext()) throw new FrameworkException("Támadó nincs megadva.");
                Hajo attacker = ParseShip(lines.Current);
                if (!lines.MoveNext()) throw new FrameworkException("Védő nincs megadva.");
                Hajo defender = ParseShip(lines.Current);
                Console.WriteLine("Támadó: " + ShipToString(attacker));
                Console.WriteLine("Védő: " + ShipToString(defender));
                Console.WriteLine("Támadó támad.");
                attacker.Tamad(defender);
                Console.WriteLine("Támadó: " + ShipToString(attacker));
                Console.WriteLine("Védő: " + ShipToString(defender));
            }
        }
        
        private static Hajo ParseShip(string line)
        {
            string[] data = line.Split(new char[] { ' ', '\t' }, 
                StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
            switch (data[0])
            {
                case "rombolo":
                    return new Csillagrombolo(int.Parse(data[4]), int.Parse(data[1]), int.Parse(data[2]),
                        int.Parse(data[3]));
                case "cirkalo":
                    return new Csillagcirkalo(int.Parse(data[1]), int.Parse(data[2]), int.Parse(data[3]));
                case "korvett":
                    return new Korvett(int.Parse(data[1]), int.Parse(data[2]), int.Parse(data[3]));
                default:
                    throw new FrameworkException($"[{line}] nem egy érvényes hajó.");
            }
        }

        private static string ShipToString(Hajo ship)
        {
            string type = ship is Csillagrombolo ? "rombolo" :
                ship is Csillagcirkalo ? "cirkalo" :
                ship is Korvett ? "korvett" : 
                throw new FrameworkException("Ismeretlen hajótípus.");
            return $"{type} {ship.Pancel} {ship.Pajzs} {ship.Sebzes}";
        }

        private static (bool Won, int Remain) GetBattleResults(Csata battle, Frakcio faction)
        {
            // magic
            const string methodName = "Eredmeny";
            MethodInfo? method = battle.GetType().GetMethod(methodName, BindingFlags.Instance | BindingFlags.Public,
                new Type[] { faction.GetType() });
            if (method != null && (method.ReturnType == typeof(ValueTuple<bool, int>) || method.ReturnType == typeof(Tuple<bool, int>)))
            {
                object? result = method.Invoke(battle, new object?[] { faction });
                if (result is null) throw new FrameworkException("Battle result should not be null");
                FieldInfo boolField = result.GetType().GetField("Item1")!;
                FieldInfo intField = result.GetType().GetField("Item2")!;
                return ((bool)boolField.GetValue(result)!, (int)intField.GetValue(result)!);
            }
            method = battle.GetType().GetMethod(methodName, BindingFlags.Instance | BindingFlags.Public,
                new Type[] { faction.GetType(), typeof(int).MakeByRefType() });
            if (method != null && method.ReturnType == typeof(bool))
            {
                object[] invokeParams = new object[]{faction, 0};
                object? result = method.Invoke(battle, invokeParams);
                if (result is null) throw new FrameworkException("Battle result should not be null");
                return ((bool)result, (int)invokeParams[1]);
            }
            method = battle.GetType().GetMethod(methodName, BindingFlags.Instance | BindingFlags.Public,
                new Type[] { faction.GetType(), typeof(bool).MakeByRefType(), typeof(int).MakeByRefType() });
            if (method != null && method.ReturnType == typeof(void))
            {
                object[] invokeParams = new object[]{faction, false, 0};
                method.Invoke(battle, invokeParams);
                return ((bool)invokeParams[1], (int)invokeParams[2]);
            }

            throw new FrameworkException(
                "Sorry, you have found a new way to write int × bool (or did not), please try something else.");
        }
    }
}
