﻿using System;
using System.Collections.Generic;
using System.Numerics;

namespace HF09
{
    public abstract class Starship
    {
        protected string name;
        protected int shield;
        protected int armor;
        protected int guard;
        protected Planet? planet;

        public string Name => name;
        public int Shield => shield;
        public Planet? Planet => planet;

        protected Starship(string n, int sh, int ar, int g)
        {
            name = n;
            shield = sh;
            armor = ar;
            guard = g;
            planet = null;
        }

        public void Protect(Planet p)
        {
            if (p == null) throw new Exception();
            if (planet != null)
            {
                planet.LeftBy(this);
            }
            planet = p;
            planet.ProtectedBy(this);
        }

        public void Leave()
        {
            if (planet == null) throw new Exception();
            planet.LeftBy(this);
            planet = null;
        }

        public abstract int FireP();
    }

    public class Wallbreaker : Starship
    {
        public Wallbreaker(string n, int sh, int ar, int g) : base(n, sh, ar, g) { }

        public override int FireP()
        {
            return armor / 2;
        }
    }

    public class Landingship : Starship
    {
        public Landingship(string n, int sh, int ar, int g) : base(n, sh, ar, g) { }

        public override int FireP()
        {
            return guard;
        }
    }

    public class Lasership : Starship
    {
        public Lasership(string n, int sh, int ar, int g) : base(n, sh, ar, g) { }

        public override int FireP()
        {
            return shield;
        }
    }

    public class Planet
    {
        public readonly string name;
        private List<Starship> ships = new List<Starship>();

        public Planet(string n)
        {
            name = n;
        }

        public void ProtectedBy(Starship h)
        {
            if (ships.Contains(h)) throw new Exception();
            ships.Add(h);
        }

        public void LeftBy(Starship h)
        {
            if (!ships.Contains(h) || h.Planet != this) throw new Exception();
            ships.Remove(h);
        }

        public int ShipCount()
        {
            return ships.Count;
        }

        public double TotalShield()
        {
            double sum = 0;
            foreach (var s in ships)
            {
                sum += s.Shield;
            }
            return sum;
        }

        public bool MaxFireP(out double max, out Starship? bestship)
        {
            if (ships.Count == 0)
            {
                max = 0;
                bestship = null;
                return false;
            }

            bestship = ships[0];
            max = bestship.FireP();

            foreach (var s in ships)
            {
                if (s.FireP() > max)
                {
                    max = s.FireP();
                    bestship = s;
                }
            }
            return true;
        }
    }

    public class Solarsystem
    {
        private List<Planet> planets;

        public Solarsystem(List<Planet> p)
        {
            planets = p;
        }

        public List<Planet> Defenseless()
        {
            List<Planet> result = new List<Planet>();
            foreach (var p in planets)
            {
                if (p.ShipCount() == 0)
                {
                    result.Add(p);
                }
            }
            return result;
        }

        public bool MaxFireShip(out Starship? bestship)
        {
            bestship = null;
            double globalMax = -1;
            bool found = false;

            foreach (var p in planets)
            {
                if (p.MaxFireP(out double currentMax, out Starship? currentBest))
                {
                    if (!found || currentMax > globalMax)
                    {
                        globalMax = currentMax;
                        bestship = currentBest;
                        found = true;
                    }
                }
            }
            return found;
        }
    }
}