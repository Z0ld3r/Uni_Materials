﻿using TextFile;

namespace bead6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TextFileReader reader = new TextFileReader("input.txt");
            int ossz = 0;
            string sor;
            bool vane = reader.ReadString(out sor);
            while (vane)
            {
                string[] f = sor.Split(' ');
                int i = 2;
                while (f.Length-1 >= 2 && i<=f.Length)
                {
                    ossz += int.Parse(f[i]);
                    i += 2;
                }
                vane = reader.ReadString(out sor);
            }
            if (!vane) { Console.WriteLine("nincs"); }
            else if (ossz == 0) { Console.WriteLine("nincs"); }
            else { Console.WriteLine(ossz); }

        }

    }
}
