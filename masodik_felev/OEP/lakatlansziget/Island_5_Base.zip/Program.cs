﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Island_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ShipwreckedTest();
            HouseTest();
            RitualTest();
            ClanTest();
            IslandTest();
        }

        static void ShipwreckedTest()
        {
            Shipwrecked sw1 = new Shipwrecked("Karcsi", 10, 20);
            sw1.ReduceStrength(6);
            CheckEq(4, sw1.Strength, "After reducing strenght by 6, strenght should be");

            Shipwrecked sw2 = new Shipwrecked("Karcsi", 10, 20);
            sw2.ReduceStrength(20);
            CheckEq(0, sw2.Strength, "After reducing strenght by 200, strenght should be");

            Shipwrecked sw3 = new Shipwrecked("Karcsi", 10, 20);
            sw3.ReduceStrength(7);
            sw3.ReduceStrength(7);
            CheckEq(0, sw3.Strength, "After reducing strenght by 7 two times, strenght should be");

            Shipwrecked sw4 = new Shipwrecked("Karcsi", 10, 20);
            sw4.Die();
            CheckEq(0, sw4.Strength, "After death, strenght should be");
        }

        static void HouseTest()
        {
            Shipwrecked sw1 = new Shipwrecked("Karcsi", 57, 20);
            Shipwrecked sw2 = new Shipwrecked("Hektor", 87, 20);
            Shipwrecked sw3 = new Shipwrecked("Thalia", 40, 20);
            sw3.Die();

            House h1 = null!;
            CheckNoException(() => h1 = new House(new List<Person>() { sw1, sw2 }), "House can be constructed without exception.");
            CheckException(() => new House(new List<Person>() { sw1 }), "House constructor throws exception when someone already has a home.");
            CheckException(() => new House(new List<Person>() { sw3 }), "House constructor throws exception when someone dead tries to build it.");

            CheckEq(54, sw1.Strength, "After working on house, strenght should be reduced by 3.");
            Check(() => sw2.Home == h1, "After working on house, it should be set as home.");
            CheckEq(10, h1.Condition, "House condition should start at 10.");

            sw2.Die();
            Check(() => !h1.Residents.Contains(sw2), "After death, person should be removed from residents.");

            h1.ReduceCondition(3);
            CheckEq(7, h1.Condition, "After reducing condition by 3, condition should be 7");

            h1.ReduceCondition(10);
            CheckEq(0, h1.Condition, "After reducing condition by 3 and 10, condition should be 0");

            Check(() => sw1.Home == null, "After house collapsing, home should be null.");
            CheckEq(44, sw1.Strength, "After house collapsing, strenght should be reduced by 10.");
        }

        static void RitualTest()
        {
            RitualTest(() => BloodPact.Instance, nameof(BloodPact), 56, new List<int> { 86, 39 }, "Performing BloodPact should reduce participant strenght by 1.", "Performing BloodPact should reduce member strenght by 1.");
            RitualTest(() => HuntBeast.Instance, nameof(HuntBeast), 52, new List<int> { 87, 40 }, "Performing HuntBeast should reduce participant strenght by 5.", "Performing HuntBeast should not affect member strenght.");
        }

        static void RitualTest(Func<JoinRitual> ritual, string ritualName, int participant, List<int> members, string participatText, string membersText)
        {
            Shipwrecked sw1 = new Shipwrecked("Karcsi", 57, 20);
            Shipwrecked sw2 = new Shipwrecked("Hektor", 87, 20);
            Shipwrecked sw3 = new Shipwrecked("Thalia", 40, 20);

            Check(() => ritual() == ritual(), $"Singleton pattern implemented for {ritualName}.");

            List<Person> membersList = new List<Person> { sw2, sw3 };
            ritual().Perform(sw1, membersList);
            CheckEq(participant, sw1.Strength, participatText);
            CheckListEq(members, membersList.Select(s => s.Strength).ToList(), membersText);
        }

        static void ClanTest()
        {
            Island i = new Desert();

            Clan c1 = new Clan("Selymescicak", new List<string> { "Mi", "Li" }, new List<int> { 15, 45 }, new List<int> { 22, 20 }, i, BloodPact.Instance);

            Check(() => 2 == c1.Members.Count, "Clan should create all members.");

            Shipwrecked sw1 = new Shipwrecked("Karcsi", 57, 20);
            Shipwrecked sw2 = new Shipwrecked("Hektor", 1, 20);
            CheckNoException(() => c1.Join(sw1), "Shipwrecked can join after successful ritual.");
            CheckException(() => c1.Join(sw1), "Shipwrecked can not join twice.");
            Check(() => sw1.Clan == c1, "Shipwrecked's clan changes after successful ritual.");
            CheckNoException(() => c1.Join(sw2), "Shipwrecked can perform unsuccessful ritual.");
            Check(() => sw2.Clan == null, "Shipwrecked's clan does not change after unsuccessful ritual.");
        }

        static void IslandTest()
        {
            Island i1 = new Tropical();

            Shipwrecked sw1 = new Shipwrecked("Karcsi", 57, 20);
            Shipwrecked sw2 = new Shipwrecked("Hektor", 87, 20);

            CheckNoException(() => i1.Arrive(sw1), "Shipwrecked can arrive on island.");
            CheckException(() => i1.Arrive(sw1), "Shipwrecked can not arrive twice on island.");
            
            CheckEq(52, sw1.Strength, "Arriving should reduce strenght by 5.");

            CheckNoException(() => i1.Build(new List<Person>() { sw1 }), "Shipwrecked can build house on island.");
            CheckException(() => i1.Build(new List<Person>() { sw2 }), "Not arrived shipwrecked can not build house on island.");

            Island i2 = new Desert();
            Check(() => i2.WeakestShipwrecked().Item1 == false, "There is no weakest on an empty island.");
            Shipwrecked sw3 = new Shipwrecked("Thalia", 40, 20);
            i2.Arrive(sw3);
            sw3.Die();
            Check(() => i2.WeakestShipwrecked().Item1 == false, "There is no weakest on an island with dead people.");
            i2.Arrive(sw2);
            Check(() => i2.WeakestShipwrecked() == (true, 82, sw2), "Weakest person is correctly choosen when there is only one person.");
            Shipwrecked sw4 = new Shipwrecked("Hugo", 12, 60);
            Shipwrecked sw5 = new Shipwrecked("Zolta", 20, 17);
            i2.Arrive(sw4);
            i2.Arrive(sw5);
            Check(() => i2.WeakestShipwrecked() == (true, 7, sw4), "Weakest person is correctly choosen with multiple people.");

            DisasterTest(new Tropical(), new List<int> { 57, 84, 40 }, new List<int> { 30, 20, 13, 43 }, new List<int> { 9, 9, 9 }, "On a tropical island, the homeless person's strenght should be reduced by 3.", "On a tropical island, the homeless inhabitants strenght should be reduced by 2.", "On a tropical island, all houses' condition should be reduced by 1.");
            DisasterTest(new Mediterranean(), new List<int> { 57, 87, 40 }, new List<int> { 30, 20, 15, 45 }, new List<int> { 8, 8, 8 }, "On a mediterranean island, strenghts should be unchanged.", "On a mediterranean island, strenghts should be unchanged.", "On a tropical island, all houses' condition should be reduced by 2.");
            DisasterTest(new Desert(), new List<int> { 57, 87, 0 }, new List<int> { 30, 0, 0, 45 }, new List<int> { 9, 9, 9 }, "On a desert island, the weakest person should die.", "On a desert island,  the oldest person in each clan should die.", "On a desert island, all houses' condition should be reduced by 1.");

            Island i3 = new Mediterranean();
            CheckListEq(new List<string> { }, i3.ClansWithHouse(), "Empty island should have no clans with house.");
            AddClan(i3, "Selyemcicak", false);
            CheckListEq(new List<string> { }, i3.ClansWithHouse(), "Island with only houseless clans should have no clans with house.");
            AddClan(i3, "Tarantullak", true);
            AddClan(i3, "Csikosok", false);
            Clan c4 = AddClan(i3, "Hatlabuak", true);
            CheckListEq(new List<string> { "Tarantullak", "Hatlabuak" }, i3.ClansWithHouse(), "Clans with houses should be listed.");
            foreach(Person p in c4.Members.ToList())
            {
                p.Die();
            }
            CheckListEq(new List<string> { "Tarantullak" }, i3.ClansWithHouse(), "After all members die, clan should be no longer listed.");
        }

        static void DisasterTest(Island i, List<int> strenghts, List<int> inhabitantStrenghts, List<int> conditions, string strenghtText, string inhabitantStrenghtText, string conditionText)
        {
            Shipwrecked sw1 = new Shipwrecked("Karcsi", 65, 20);
            Shipwrecked sw2 = new Shipwrecked("Hektor", 92, 20);
            Shipwrecked sw3 = new Shipwrecked("Thalia", 48, 20);

            i.Arrive(sw1);
            i.Arrive(sw2);
            i.Arrive(sw3);
            List<Shipwrecked> shipwreckeds = new List<Shipwrecked>() { sw1, sw2, sw3 };

            i.NewClanAppears("Tarantullak", new List<string> { "Mu", "Hu" }, new List<int> { 33, 23 }, new List<int> { 35, 90 }, BloodPact.Instance);
            i.NewClanAppears("Selymescicak", new List<string> { "Mi", "Li" }, new List<int> { 15, 45 }, new List<int> { 22, 20 }, BloodPact.Instance);
            List<Inhabitant> inhabitants = i.Inhabitants.ToList();

            i.Build(new List<Person> { sw1 });
            i.Build(new List<Person> { sw3 });
            i.Build(i.Clans.First());

            List<House> houses = new List<House>() { sw1.Home!, sw3.Home!, i.Clans.First().House! };

            i.Disaster();

            CheckListEq(strenghts, shipwreckeds.Select(s => s.Strength).ToList(), strenghtText);
            CheckListEq(inhabitantStrenghts, inhabitants.Select(s => s.Strength).ToList(), inhabitantStrenghtText);
            CheckListEq(conditions, houses.Select(h => h.Condition).ToList(), conditionText);
        }

        static Clan AddClan(Island i, string name, bool house)
        {
            i.NewClanAppears(name, new List<string> { "Mi", "Li" }, new List<int> { 15, 45 }, new List<int> { 22, 20 }, BloodPact.Instance);
            Clan c = i.Clans.Last();
            if (house)
            {
                i.Build(c);
            }
            return c;
        }


        static void Check(Func<bool> func, string text, bool expectException = false)
        {
            bool good = false;
            try
            {
                good = func.Invoke();
                if (expectException)
                {
                    good = false;
                }
            }
            catch (Exception)
            {
                good = expectException;
            }

            if (good)
            {
                Console.BackgroundColor = ConsoleColor.Green;
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(text + " - OK");
            }
            else
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(text + " - NOT OK");
            }
            Console.ResetColor();
        }

        static void CheckException(Action func, string text)
        {
            Check(() => { func.Invoke(); return false; }, text, true);
        }

        static void CheckNoException(Action func, string text)
        {
            Check(() => { func.Invoke(); return true; }, text, false);
        }

        static void CheckEq<T>(T expected, T actual, string text)
        {
            Check(() => expected!.Equals(actual), text + $" Expected: {expected}, Actual: {actual}", false);
        }

        static void CheckListEq<T>(List<T> expected, List<T> actual, string text)
        {
            string expectedText = "{ " + string.Join(", ", expected) + " }";
            string actualText = "{ " + string.Join(", ", actual) + " }";
            Check(() => expected.Count() == actual.Count() && expected.Zip(actual).All(pair => pair.First!.Equals(pair.Second)),
                text + $" Expected: {expectedText}, Actual: {actualText}");
        }

        static void Label(string text)
        {
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(text);
            Console.ResetColor();
        }
    }
}
